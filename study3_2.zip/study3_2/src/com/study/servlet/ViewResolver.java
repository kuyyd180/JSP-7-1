package com.study.servlet;

public interface ViewResolver {
	public String prefix="/WEB-INF/views/";
	public String suffix=".jsp";
}
